MafiaPedi2_Android_Scaffold/
├── README.md
├── build.gradle.kts
├── settings.gradle.kts
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/model-fa/README.txt
│       ├── java/com/pedram/mafiacoach/
│       │   ├── audio/
│       │   │   ├── AudioRecorder.kt
│       │   │   └── VoskManager.kt
│       │   ├── analyzer/
│       │   │   ├── DialogueAdvisor.kt
│       │   │   ├── HeuristicAnalyzer.kt
│       │   │   ├── SuspicionEngine.kt
│       │   │   └── SuspicionResult.kt
│       │   ├── graph/
│       │   │   ├── MafiaGraphView.kt
│       │   │   └── TargetGraph.kt
│       │   ├── models/
│       │   │   ├── GameState.kt
│       │   │   ├── Player.kt
│       │   │   ├── SpeechLog.kt
│       │   │   └── TargetEdge.kt
│       │   ├── storage/
│       │   │   └── SaveManager.kt
│       │   └── ui/
│       │       ├── MainActivity.kt
│       │       └── SimpleItemSelectedListener.kt
│       └── res/
│           ├── layout/activity_main.xml
│           └── values/
│               ├── colors.xml
│               ├── strings.xml
│               └── themes.xml
