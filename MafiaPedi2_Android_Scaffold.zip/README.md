# MafiaPedi2 Android Scaffold

این ZIP یک اسکلت کامل برای پروژه‌ی Android آفلاین MafiaPedi2 است.

## ساختار مهم
- `app/src/main/assets/model-fa/`  
  مدل Vosk باید داخل همین پوشه قرار بگیرد.
- `app/src/main/java/com/pedram/mafiacoach/audio/VoskManager.kt`  
  شامل کپی بازگشتی (recursive) مدل از assets به حافظه داخلی است.
- `app/src/main/java/com/pedram/mafiacoach/audio/AudioRecorder.kt`  
  ضبط و تبدیل گفتار به متن با Vosk.
- `app/src/main/java/com/pedram/mafiacoach/graph/MafiaGraphView.kt`  
  نمودار تارگت Tap → Tap.
- `app/src/main/java/com/pedram/mafiacoach/analyzer/*`  
  تحلیل رفتار و پیشنهاد دیالوگ.

## نکته
فایل‌های مدل واقعی Vosk خیلی حجیم هستند و داخل ZIP قرار نگرفته‌اند.  
فقط ساختار پوشه آماده است؛ مدل را باید جداگانه در `assets/model-fa/` بگذاری.
