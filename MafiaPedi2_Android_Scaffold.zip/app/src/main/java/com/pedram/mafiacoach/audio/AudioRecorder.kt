package com.pedram.mafiacoach.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.vosk.Model
import org.vosk.Recognizer

class AudioRecorder(
    private val context: Context,
    private val modelPath: String,
    private val onResult: (String) -> Unit
) {
    private var recorder: AudioRecord? = null
    private var recognizer: Recognizer? = null
    private var model: Model? = null
    private var job: Job? = null
    private var isRecording = false

    private val sampleRate = 16000
    private val bufferSize = maxOf(
        AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ),
        2048
    )

    fun start() {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            onResult("{"error":"permission_denied"}")
            return
        }

        if (isRecording) return

        try {
            model = Model(modelPath)
            recognizer = Recognizer(model, sampleRate.toFloat())

            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            recorder?.startRecording()
            isRecording = true

            job = CoroutineScope(Dispatchers.IO).launch {
                val buffer = ByteArray(bufferSize)
                while (isRecording) {
                    val read = recorder?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        if (recognizer?.acceptWaveForm(buffer, read) == true) {
                            onResult(recognizer?.result ?: "")
                        } else {
                            onResult(recognizer?.partialResult ?: "")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            onResult("{"error":"${e.message ?: "vosk_error"}"}")
        }
    }

    fun stop() {
        isRecording = false
        job?.cancel()
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { recognizer?.close() } catch (_: Exception) {}
        try { model?.close() } catch (_: Exception) {}
        recorder = null
        recognizer = null
        model = null
        job = null
    }
}
