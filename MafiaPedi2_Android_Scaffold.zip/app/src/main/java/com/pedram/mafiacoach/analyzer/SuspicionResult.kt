package com.pedram.mafiacoach.analyzer

data class SuspicionResult(
    val playerId: Int,
    val score: Int,
    val reasons: List<String>
)
