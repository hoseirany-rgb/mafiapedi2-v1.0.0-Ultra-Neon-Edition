package com.pedram.mafiacoach.models

data class Player(
    val id: Int,
    var name: String = "Player",
    var alive: Boolean = true,
    var role: String = "Citizen",
    var mafiaProbability: Int = 0,
    var note: String = ""
)
