package com.pedram.mafiacoach.models

data class TargetEdge(
    val from: Int,
    val to: Int,
    val createdAt: Long = System.currentTimeMillis()
)
