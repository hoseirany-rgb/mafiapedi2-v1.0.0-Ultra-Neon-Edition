package com.pedram.mafiacoach.models

data class GameState(
    var playerCount: Int = 12,
    var scenario: String = "classic",
    var day: Int = 1,
    var selectedSpeakerId: Int = 1,
    var players: MutableList<Player> = mutableListOf(),
    var edges: MutableList<TargetEdge> = mutableListOf(),
    var logs: MutableList<SpeechLog> = mutableListOf()
)
