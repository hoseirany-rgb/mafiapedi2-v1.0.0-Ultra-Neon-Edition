package com.pedram.mafiacoach.ui

import android.Manifest
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pedram.mafiacoach.R
import com.pedram.mafiacoach.analyzer.DialogueAdvisor
import com.pedram.mafiacoach.analyzer.HeuristicAnalyzer
import com.pedram.mafiacoach.analyzer.SuspicionEngine
import com.pedram.mafiacoach.audio.AudioRecorder
import com.pedram.mafiacoach.audio.VoskManager
import com.pedram.mafiacoach.graph.MafiaGraphView
import com.pedram.mafiacoach.models.GameState
import com.pedram.mafiacoach.models.Player
import com.pedram.mafiacoach.models.SpeechLog
import com.pedram.mafiacoach.storage.SaveManager
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtTranscript: TextView
    private lateinit var txtAdvisor: TextView
    private lateinit var txtAnalysis: TextView
    private lateinit var spinnerSpeaker: Spinner
    private lateinit var spinnerScenario: Spinner
    private lateinit var editNote: EditText
    private lateinit var graphView: MafiaGraphView

    private var recorder: AudioRecorder? = null
    private var state: GameState = GameState()

    private val engine = SuspicionEngine(HeuristicAnalyzer())
    private val advisor = DialogueAdvisor()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else toast("مجوز ضبط صدا داده نشد")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupSpinners()
        setupGraphCallbacks()
        setupButtons()

        val loaded = SaveManager.load(this)
        if (loaded != null) {
            state = loaded
            refreshUi()
            toast("آخرین بازی بارگذاری شد")
        } else {
            newGame()
        }
    }

    override fun onStop() {
        super.onStop()
        recorder?.stop()
    }

    private fun bindViews() {
        txtStatus = findViewById(R.id.txtStatus)
        txtTranscript = findViewById(R.id.txtTranscript)
        txtAdvisor = findViewById(R.id.txtAdvisor)
        txtAnalysis = findViewById(R.id.txtAnalysis)
        spinnerSpeaker = findViewById(R.id.spinnerSpeaker)
        spinnerScenario = findViewById(R.id.spinnerScenario)
        editNote = findViewById(R.id.editNote)
        graphView = findViewById(R.id.graphView)
    }

    private fun setupSpinners() {
        val scenarioAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("classic", "godfather", "twoDoctors", "inspector")
        )
        spinnerScenario.adapter = scenarioAdapter
        spinnerScenario.setSelection(0)
        spinnerScenario.onItemSelectedListener = SimpleItemSelectedListener { position ->
            state.scenario = when (position) {
                1 -> "godfather"
                2 -> "twoDoctors"
                3 -> "inspector"
                else -> "classic"
            }
            applyRoles()
            refreshUi()
            saveNow()
        }
    }

    private fun setupGraphCallbacks() {
        graphView.onSelectionChanged = { selected ->
            txtStatus.text = if (selected == null) {
                "بازیکن انتخاب نشده است"
            } else {
                "بازیکن انتخاب‌شده برای تارگت: Player $selected"
            }
        }

        graphView.onGraphChanged = {
            refreshAnalysis()
            saveNow()
            txtStatus.text = "تغییر ثبت شد"
        }

        graphView.gameState = state
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (state.players.isEmpty()) newGame()
            checkPermissionAndStart()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            recorder?.stop()
            txtStatus.text = "ضبط متوقف شد"
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            saveNow()
        }

        findViewById<Button>(R.id.btnLoad).setOnClickListener {
            loadNow()
        }

        findViewById<Button>(R.id.btnNewGame).setOnClickListener {
            newGame()
        }

        findViewById<Button>(R.id.btnResetEdges).setOnClickListener {
            state.edges.clear()
            graphView.invalidate()
            refreshAnalysis()
            saveNow()
        }

        findViewById<Button>(R.id.btnAddNote).setOnClickListener {
            val note = editNote.text?.toString()?.trim().orEmpty()
            if (note.isBlank()) return@setOnClickListener
            val speaker = state.selectedSpeakerId
            state.players.firstOrNull { it.id == speaker }?.note = note
            state.logs.add(SpeechLog(speaker, note))
            editNote.text?.clear()
            refreshAnalysis()
            saveNow()
        }

        spinnerSpeaker.onItemSelectedListener = SimpleItemSelectedListener { position ->
            state.selectedSpeakerId = position + 1
            refreshAnalysis()
        }
    }

    private fun newGame() {
        val count = 12
        state = GameState(
            playerCount = count,
            scenario = when (spinnerScenario.selectedItemPosition) {
                1 -> "godfather"
                2 -> "twoDoctors"
                3 -> "inspector"
                else -> "classic"
            },
            day = 1,
            selectedSpeakerId = 1
        )
        state.players = (1..count).map { id ->
            Player(
                id = id,
                name = "Player $id",
                alive = true,
                role = "Citizen",
                mafiaProbability = 0,
                note = ""
            )
        }.toMutableList()

        applyRoles()
        updateSpeakerSpinner()
        graphView.gameState = state
        txtTranscript.text = "..."
        txtAdvisor.text = "..."
        txtAnalysis.text = "..."
        txtStatus.text = "بازی جدید آماده شد"
        saveNow()
    }

    private fun applyRoles() {
        val scenarioRoles = when (state.scenario) {
            "godfather" -> listOf("Godfather", "Mafia", "Doctor", "Detective", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen")
            "twoDoctors" -> listOf("Mafia", "Doctor", "Doctor", "Citizen", "Citizen", "Detective", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen")
            "inspector" -> listOf("Mafia", "Inspector", "Doctor", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen")
            else -> listOf("Mafia", "Doctor", "Detective", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen", "Citizen")
        }
        state.players.forEachIndexed { index, player ->
            player.role = scenarioRoles.getOrNull(index) ?: "Citizen"
        }
    }

    private fun updateSpeakerSpinner() {
        val names = state.players.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinnerSpeaker.adapter = adapter
        spinnerSpeaker.setSelection((state.selectedSpeakerId - 1).coerceIn(0, names.lastIndex.coerceAtLeast(0)))
        spinnerSpeaker.onItemSelectedListener = SimpleItemSelectedListener { position ->
            state.selectedSpeakerId = position + 1
            refreshAnalysis()
        }
    }

    private fun refreshUi() {
        updateSpeakerSpinner()
        graphView.gameState = state
        graphView.invalidate()
        refreshAnalysis()
    }

    private fun refreshAnalysis() {
        val currentSpeaker = state.selectedSpeakerId
        val currentText = state.logs.lastOrNull()?.text.orEmpty()
        val result = if (currentText.isNotBlank()) {
            engine.evaluate(state, currentSpeaker, currentText)
        } else {
            null
        }

        txtAnalysis.text = buildString {
            append("سناریو: ${state.scenario}
")
            append("روز: ${state.day}
")
            append("گوینده فعلی: Player $currentSpeaker
")
            append("تارگت‌ها: ${state.edges.size}

")
            if (result != null) {
                append("امتیاز: ${result.score}%
")
                append("دلایل:
")
                result.reasons.forEach { append("• $it
") }
            } else {
                append("هنوز تحلیلی ثبت نشده است.")
            }
        }

        val advice = result?.let { advisor.recommend(it) }
        txtAdvisor.text = advice?.let { "${it.title}
${it.message}" }
            ?: "دیالوگ پیشنهادی اینجا نمایش داده می‌شود."
    }

    private fun checkPermissionAndStart() {
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (granted) startListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        txtStatus.text = "در حال آماده‌سازی مدل..."
        Thread {
            val modelPath = VoskManager.prepareModel(this)
            runOnUiThread {
                recorder?.stop()
                recorder = AudioRecorder(this, modelPath) { raw ->
                    handleRecognizerOutput(raw)
                }
                recorder?.start()
                txtStatus.text = "شنیدن فعال شد"
            }
        }.start()
    }

    private fun handleRecognizerOutput(raw: String) {
        try {
            val json = JSONObject(raw)
            val finalText = json.optString("text", "")
            val partialText = json.optString("partial", "")
            val errorText = json.optString("error", "")

            runOnUiThread {
                when {
                    errorText.isNotBlank() -> {
                        txtStatus.text = "خطا: $errorText"
                    }
                    finalText.isNotBlank() -> {
                        val speaker = state.selectedSpeakerId
                        txtTranscript.text = "گوینده: Player $speaker

$finalText"

                        state.logs.add(SpeechLog(speaker, finalText))
                        val result = engine.evaluate(state, speaker, finalText)
                        val advice = advisor.recommend(result)

                        txtAdvisor.text = "${advice.title}
${advice.message}"
                        txtAnalysis.text = buildString {
                            append("امتیاز: ${result.score}%
")
                            append("دلایل:
")
                            result.reasons.forEach { append("• $it
") }
                        }

                        graphView.invalidate()
                        saveNow()
                    }
                    partialText.isNotBlank() -> {
                        txtTranscript.text = "گوینده: Player ${state.selectedSpeakerId}

$partialText"
                    }
                }
            }
        } catch (_: Exception) {
            runOnUiThread {
                txtStatus.text = "خروجی قابل‌خواندن نبود"
            }
        }
    }

    private fun saveNow() {
        SaveManager.save(this, state)
        txtStatus.text = "ذخیره شد"
    }

    private fun loadNow() {
        val loaded = SaveManager.load(this)
        if (loaded == null) {
            toast("فایل ذخیره‌ای وجود ندارد")
            return
        }
        state = loaded
        if (state.players.isEmpty()) {
            state.players = (1..state.playerCount).map { id -> Player(id, "Player $id") }.toMutableList()
            applyRoles()
        }
        refreshUi()
        txtStatus.text = "بازی ادامه داده شد"
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
