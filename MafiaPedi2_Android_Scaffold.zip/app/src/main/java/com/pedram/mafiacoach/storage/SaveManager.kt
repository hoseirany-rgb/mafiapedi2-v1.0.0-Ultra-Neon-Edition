package com.pedram.mafiacoach.storage

import android.content.Context
import com.pedram.mafiacoach.models.GameState
import com.pedram.mafiacoach.models.Player
import com.pedram.mafiacoach.models.SpeechLog
import com.pedram.mafiacoach.models.TargetEdge
import org.json.JSONArray
import org.json.JSONObject

object SaveManager {
    private const val FILE_NAME = "mafiapedi2_save.json"

    fun save(context: Context, state: GameState) {
        val json = JSONObject()
        json.put("playerCount", state.playerCount)
        json.put("scenario", state.scenario)
        json.put("day", state.day)
        json.put("selectedSpeakerId", state.selectedSpeakerId)

        val players = JSONArray()
        state.players.forEach { p ->
            players.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("alive", p.alive)
                    .put("role", p.role)
                    .put("mafiaProbability", p.mafiaProbability)
                    .put("note", p.note)
            )
        }
        json.put("players", players)

        val edges = JSONArray()
        state.edges.forEach { e ->
            edges.put(
                JSONObject()
                    .put("from", e.from)
                    .put("to", e.to)
                    .put("createdAt", e.createdAt)
            )
        }
        json.put("edges", edges)

        val logs = JSONArray()
        state.logs.forEach { l ->
            logs.put(
                JSONObject()
                    .put("speakerId", l.speakerId)
                    .put("text", l.text)
                    .put("timestamp", l.timestamp)
            )
        }
        json.put("logs", logs)

        context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE).use { out ->
            out.write(json.toString(2).toByteArray(Charsets.UTF_8))
        }
    }

    fun load(context: Context): GameState? {
        val file = context.getFileStreamPath(FILE_NAME)
        if (!file.exists()) return null

        val json = JSONObject(file.readText(Charsets.UTF_8))
        val state = GameState(
            playerCount = json.optInt("playerCount", 12),
            scenario = json.optString("scenario", "classic"),
            day = json.optInt("day", 1),
            selectedSpeakerId = json.optInt("selectedSpeakerId", 1)
        )

        val playersArr = json.optJSONArray("players") ?: JSONArray()
        for (i in 0 until playersArr.length()) {
            val p = playersArr.getJSONObject(i)
            state.players.add(
                Player(
                    id = p.getInt("id"),
                    name = p.optString("name", "Player ${p.getInt("id")}"),
                    alive = p.optBoolean("alive", true),
                    role = p.optString("role", "Citizen"),
                    mafiaProbability = p.optInt("mafiaProbability", 0),
                    note = p.optString("note", "")
                )
            )
        }

        val edgesArr = json.optJSONArray("edges") ?: JSONArray()
        for (i in 0 until edgesArr.length()) {
            val e = edgesArr.getJSONObject(i)
            state.edges.add(
                TargetEdge(
                    from = e.getInt("from"),
                    to = e.getInt("to"),
                    createdAt = e.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val logsArr = json.optJSONArray("logs") ?: JSONArray()
        for (i in 0 until logsArr.length()) {
            val l = logsArr.getJSONObject(i)
            state.logs.add(
                SpeechLog(
                    speakerId = l.getInt("speakerId"),
                    text = l.getString("text"),
                    timestamp = l.optLong("timestamp", System.currentTimeMillis())
                )
            )
        }

        return state
    }
}
