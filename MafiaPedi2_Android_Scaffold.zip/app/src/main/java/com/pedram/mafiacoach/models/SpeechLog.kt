package com.pedram.mafiacoach.models

data class SpeechLog(
    val speakerId: Int,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
