package com.pedram.mafiacoach.graph

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.pedram.mafiacoach.models.GameState
import com.pedram.mafiacoach.models.TargetEdge
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class MafiaGraphView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var gameState: GameState? = null
        set(value) {
            field = value
            selectedPlayerId = null
            invalidate()
        }

    var selectedPlayerId: Int? = null
        set(value) {
            field = value
            invalidate()
        }

    var onSelectionChanged: ((Int?) -> Unit)? = null
    var onGraphChanged: (() -> Unit)? = null

    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        textAlign = Paint.Align.CENTER
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY
        textSize = 22f
        textAlign = Paint.Align.CENTER
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8095B3")
        strokeWidth = 6f
        style = Paint.Style.STROKE
    }

    private val touchRadius = 46f
    private var widthCenter = 0f
    private var heightCenter = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = gameState ?: return
        val players = state.players
        if (players.isEmpty()) return

        widthCenter = width / 2f
        heightCenter = height / 2f

        val radius = min(width, height) * 0.34f
        val positions = players.mapIndexed { index, player ->
            val angle = (Math.PI * 2 * index / players.size) - Math.PI / 2
            val x = widthCenter + cos(angle).toFloat() * radius
            val y = heightCenter + sin(angle).toFloat() * radius
            player.id to (x to y)
        }.toMap()

        state.edges.forEach { edge ->
            val from = positions[edge.from] ?: return@forEach
            val to = positions[edge.to] ?: return@forEach
            canvas.drawLine(from.first, from.second, to.first, to.second, edgePaint)
        }

        players.forEach { player ->
            val pos = positions[player.id] ?: return@forEach
            val prob = TargetGraph.combinedProbability(player, state.edges)
            val fill = when {
                prob >= 70 -> Color.parseColor("#E74C3C")
                prob >= 40 -> Color.parseColor("#F1C40F")
                else -> Color.parseColor("#2ECC71")
            }

            nodePaint.color = fill
            canvas.drawCircle(pos.first, pos.second, 42f, nodePaint)

            if (selectedPlayerId == player.id) {
                val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                }
                canvas.drawCircle(pos.first, pos.second, 48f, ring)
            }

            canvas.drawText(player.name, pos.first, pos.second - 8f, textPaint)
            canvas.drawText("$prob% Mafia", pos.first, pos.second + 18f, smallPaint)
            canvas.drawText(if (player.alive) "Alive" else "Dead", pos.first, pos.second + 40f, smallPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val state = gameState ?: return true
        val players = state.players
        if (players.isEmpty()) return true

        val radius = min(width, height) * 0.34f
        val positions = players.mapIndexed { index, player ->
            val angle = (Math.PI * 2 * index / players.size) - Math.PI / 2
            val x = widthCenter + cos(angle).toFloat() * radius
            val y = heightCenter + sin(angle).toFloat() * radius
            player.id to (x to y)
        }.toMap()

        val tapped = players.firstOrNull { player ->
            val pos = positions[player.id] ?: return@firstOrNull false
            hypot(event.x - pos.first, event.y - pos.second) <= touchRadius
        } ?: return true

        if (selectedPlayerId == null) {
            selectedPlayerId = tapped.id
            onSelectionChanged?.invoke(selectedPlayerId)
            invalidate()
            return true
        }

        if (selectedPlayerId == tapped.id) {
            selectedPlayerId = null
            onSelectionChanged?.invoke(null)
            invalidate()
            return true
        }

        state.edges.add(TargetEdge(from = selectedPlayerId!!, to = tapped.id))
        selectedPlayerId = null
        onSelectionChanged?.invoke(null)
        onGraphChanged?.invoke()
        invalidate()
        return true
    }
}
