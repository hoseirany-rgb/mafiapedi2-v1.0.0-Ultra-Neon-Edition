package com.pedram.mafiacoach.graph

import com.pedram.mafiacoach.models.Player
import com.pedram.mafiacoach.models.TargetEdge
import kotlin.math.max
import kotlin.math.min

object TargetGraph {

    fun incomingCount(playerId: Int, edges: List<TargetEdge>): Int =
        edges.count { it.to == playerId }

    fun outgoingCount(playerId: Int, edges: List<TargetEdge>): Int =
        edges.count { it.from == playerId }

    fun uniqueTargets(playerId: Int, edges: List<TargetEdge>): Int =
        edges.filter { it.from == playerId }.map { it.to }.distinct().size

    fun combinedProbability(player: Player, edges: List<TargetEdge>): Int {
        val edgeScore = incomingCount(player.id, edges) * 18 +
                outgoingCount(player.id, edges) * 6 +
                max(0, uniqueTargets(player.id, edges) - 1) * 7
        return min(95, max(player.mafiaProbability, edgeScore))
    }
}
