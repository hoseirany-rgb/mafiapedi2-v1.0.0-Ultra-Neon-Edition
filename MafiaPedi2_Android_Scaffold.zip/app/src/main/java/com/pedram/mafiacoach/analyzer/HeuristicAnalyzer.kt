package com.pedram.mafiacoach.analyzer

import com.pedram.mafiacoach.models.GameState
import kotlin.math.max
import kotlin.math.min

class HeuristicAnalyzer {

    fun analyze(state: GameState, speakerId: Int, text: String): SuspicionResult {
        val reasons = mutableListOf<String>()
        val lowered = text.lowercase()

        val incoming = state.edges.count { it.to == speakerId }
        val outgoing = state.edges.count { it.from == speakerId }
        val uniqueTargets = state.edges.filter { it.from == speakerId }.map { it.to }.distinct().size

        var score = 0

        score += incoming * 12
        if (incoming > 0) reasons += "تارگت ورودی دریافت کرده است: $incoming"

        score += outgoing * 6
        if (outgoing > 0) reasons += "تارگت‌های خروجی ثبت شده: $outgoing"

        if (uniqueTargets > 1) {
            score += 10
            reasons += "چرخش در تارگت‌ها"
        }

        val suspicionKeywords = listOf("تناقض", "عوض", "تغییر", "دفاع", "موج", "مشکوک", "فرار")
        val attackKeywords = listOf("فکت", "حمله", "تارگت", "رأی", "رای", "تحلیل")

        suspicionKeywords.forEach { key ->
            if (lowered.contains(key)) {
                score += 7
                reasons += "واژه‌ی حساس دیده شد: $key"
            }
        }

        attackKeywords.forEach { key ->
            if (lowered.contains(key)) {
                score += 3
                reasons += "نشانه‌ی تحلیلی/تهاجمی: $key"
            }
        }

        if (lowered.contains("من شهروند هستم") || lowered.contains("شهروند هستم")) {
            score += 4
            reasons += "ادعای مستقیم نقش"
        }

        if (lowered.contains("من مافیا نیستم")) {
            score += 2
            reasons += "دفاع مستقیم از خود"
        }

        if (lowered.length < 20) {
            score += 2
            reasons += "پاسخ بسیار کوتاه"
        }

        score = min(95, max(0, score))
        if (reasons.isEmpty()) reasons += "الگوی خاصی ثبت نشد؛ نیاز به رصد بیشتر"

        return SuspicionResult(
            playerId = speakerId,
            score = score,
            reasons = reasons
        )
    }
}
