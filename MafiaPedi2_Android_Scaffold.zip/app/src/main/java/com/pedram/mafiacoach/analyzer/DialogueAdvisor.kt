package com.pedram.mafiacoach.analyzer

class DialogueAdvisor {

    data class Advice(
        val title: String,
        val message: String
    )

    fun recommend(result: SuspicionResult): Advice {
        return when {
            result.score >= 70 -> Advice(
                title = "دیالوگ دفاعی",
                message = "الان روی شفاف‌سازی، رد تناقض‌ها و توضیح مستقیم فکت‌ها تمرکز کن."
            )
            result.score >= 40 -> Advice(
                title = "دیالوگ اتهام",
                message = "الان بهترین کار فشار روی موج‌سواری، تغییر رأی و تناقض‌های طرف مقابل است."
            )
            else -> Advice(
                title = "دیالوگ تحلیلی",
                message = "آرام و شفاف حرف بزن، دو یا سه فکت روشن بده و بازی را قابل‌ردیابی نگه دار."
            )
        }
    }
}
