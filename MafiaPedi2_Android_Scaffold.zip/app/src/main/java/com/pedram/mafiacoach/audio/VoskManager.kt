package com.pedram.mafiacoach.audio

import android.content.Context
import java.io.File
import java.io.FileOutputStream

object VoskManager {

    fun prepareModel(context: Context): String {
        val outDir = File(context.filesDir, "model-fa")
        if (outDir.exists() && outDir.listFiles()?.isNotEmpty() == true) {
            return outDir.absolutePath
        }

        copyAssetFolder(context, "model-fa", outDir)
        return outDir.absolutePath
    }

    private fun copyAssetFolder(
        context: Context,
        assetPath: String,
        destinationDir: File
    ) {
        val assetManager = context.assets
        val items = assetManager.list(assetPath) ?: return

        if (!destinationDir.exists()) {
            destinationDir.mkdirs()
        }

        for (item in items) {
            val assetFilePath = if (assetPath.isEmpty()) item else "$assetPath/$item"
            val outFile = File(destinationDir, item)
            val subItems = assetManager.list(assetFilePath)

            if (subItems.isNullOrEmpty()) {
                assetManager.open(assetFilePath).use { input ->
                    FileOutputStream(outFile).use { output ->
                        input.copyTo(output)
                    }
                }
            } else {
                copyAssetFolder(context, assetFilePath, outFile)
            }
        }
    }
}
