package com.pedram.mafiacoach.analyzer

import com.pedram.mafiacoach.models.GameState

class SuspicionEngine(
    private val analyzer: HeuristicAnalyzer = HeuristicAnalyzer()
) {
    fun evaluate(state: GameState, speakerId: Int, text: String): SuspicionResult {
        val result = analyzer.analyze(state, speakerId, text)
        state.players.firstOrNull { it.id == speakerId }?.mafiaProbability = result.score
        return result
    }
}
